package com.example.data.repository

import com.example.data.local.RouterLogDao
import com.example.data.local.RouterLogEntity
import com.example.data.local.SecurePreferencesManager
import com.example.data.model.RouterCapabilities
import com.example.data.model.RouterConfig
import com.example.data.model.RouterLog
import com.example.router.RouterClient
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RouterRepository(
    private val securePrefs: SecurePreferencesManager,
    private val logDao: RouterLogDao,
    private val routerClient: RouterClient
) {
    val allLogs: Flow<List<RouterLog>> = logDao.getAllLogs().map { list ->
        list.map { it.toDomain() }
    }

    fun getRouterConfig(): RouterConfig = securePrefs.getRouterConfig()

    fun saveRouterConfig(config: RouterConfig) {
        securePrefs.saveRouterConfig(config)
    }

    suspend fun testConnection(config: RouterConfig): Result<RouterCapabilities> {
        val result = routerClient.testConnection(config)
        val isSuccess = result.isSuccess
        val updated = config.copy(
            isConnected = isSuccess,
            lastConnectedTimestamp = System.currentTimeMillis()
        )
        saveRouterConfig(updated)

        addLog(
            deviceName = "Router Gateway",
            macAddress = "00:00:00:00:00:00",
            action = "TEST_CONNECTION",
            status = if (isSuccess) "SUCCESS" else "FAILED",
            details = if (isSuccess) "Connected successfully to ${config.baseUrl}" else "Failed to connect to router",
            errorMessage = result.exceptionOrNull()?.message ?: ""
        )

        return result
    }

    suspend fun addLog(
        deviceName: String,
        macAddress: String,
        action: String,
        status: String,
        details: String,
        errorMessage: String = ""
    ) {
        val log = RouterLog(
            timestamp = System.currentTimeMillis(),
            deviceName = deviceName,
            macAddress = macAddress,
            action = action,
            status = status,
            details = details,
            errorMessage = errorMessage
        )
        logDao.insertLog(RouterLogEntity.fromDomain(log))
    }

    suspend fun clearLogs() {
        logDao.clearLogs()
    }
}
