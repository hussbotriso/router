package com.example.data.model

enum class SpeedLimitPreset(
    val displayName: String,
    val downKbps: Int,
    val upKbps: Int
) {
    FULL("Full Speed (Unlimited)", 0, 0),
    LIGHT("Light Limit (2 Mbps / 512 Kbps)", 2048, 512),
    HEAVY("Heavy Limit (512 Kbps / 128 Kbps)", 512, 128),
    CUSTOM("Custom Limit", -1, -1);

    companion object {
        fun fromKbps(downKbps: Int, upKbps: Int): SpeedLimitPreset {
            return when {
                downKbps <= 0 && upKbps <= 0 -> FULL
                downKbps == 2048 && upKbps == 512 -> LIGHT
                downKbps == 512 && upKbps == 128 -> HEAVY
                else -> CUSTOM
            }
        }
    }
}
