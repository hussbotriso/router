package com.example.data.repository

import com.example.data.local.DeviceDao
import com.example.data.local.DeviceEntity
import com.example.data.model.BlockMethod
import com.example.data.model.Device
import com.example.data.model.RouterConfig
import com.example.router.NetworkScanner
import com.example.router.RouterClient
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class DeviceRepository(
    private val deviceDao: DeviceDao,
    private val routerClient: RouterClient,
    private val networkScanner: NetworkScanner,
    private val routerRepository: RouterRepository
) {
    val allDevices: Flow<List<Device>> = deviceDao.getAllDevices().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun toggleBlockState(config: RouterConfig, device: Device, block: Boolean): Result<Boolean> {
        val updatedDevice = device.copy(isBlocked = block)

        // 1. Update local Room database immediately for responsive UI
        deviceDao.updateBlockState(device.macAddress.uppercase(), block)

        // 2. Trigger Router automation action
        val routerResult = if (block) {
            routerClient.blockDevice(config, updatedDevice)
        } else {
            routerClient.unblockDevice(config, updatedDevice)
        }

        val actionName = if (block) "BLOCK_INTERNET" else "UNBLOCK_INTERNET"
        val statusText = if (routerResult.isSuccess) "SUCCESS" else "MANUAL_FALLBACK"
        val details = if (routerResult.isSuccess) {
            "Router automation rule applied using ${device.blockMethod.displayName}."
        } else {
            "Automated HTTP command failed. Local profile updated. Assisted Manual Mode rule generated."
        }

        // 3. Record in activity log
        routerRepository.addLog(
            deviceName = device.displayName,
            macAddress = device.macAddress,
            action = actionName,
            status = statusText,
            details = details,
            errorMessage = routerResult.exceptionOrNull()?.message ?: ""
        )

        return routerResult
    }

    suspend fun updateSpeedLimits(
        config: RouterConfig,
        device: Device,
        isLimited: Boolean,
        downKbps: Int,
        upKbps: Int
    ): Result<Boolean> {
        val updatedDevice = device.copy(
            isLimited = isLimited,
            speedLimitDownKbps = downKbps,
            speedLimitUpKbps = upKbps
        )

        deviceDao.updateSpeedLimits(device.macAddress.uppercase(), isLimited, downKbps, upKbps)

        val routerResult = routerClient.setDeviceSpeedLimit(config, updatedDevice, downKbps, upKbps)

        routerRepository.addLog(
            deviceName = device.displayName,
            macAddress = device.macAddress,
            action = "SET_SPEED_LIMIT",
            status = if (routerResult.isSuccess) "SUCCESS" else "MANUAL_FALLBACK",
            details = "Limit set to $downKbps Kbps Down / $upKbps Kbps Up.",
            errorMessage = routerResult.exceptionOrNull()?.message ?: ""
        )

        return routerResult
    }

    suspend fun saveDevice(device: Device) {
        deviceDao.insertOrUpdate(DeviceEntity.fromDomain(device))
    }

    suspend fun deleteDevice(macAddress: String) {
        deviceDao.deleteByMac(macAddress.uppercase())
    }

    suspend fun refreshFromRouter(config: RouterConfig): Result<Int> {
        val routerFetch = routerClient.fetchConnectedDevices(config)
        var count = 0
        if (routerFetch.isSuccess) {
            val devices = routerFetch.getOrDefault(emptyList())
            for (dev in devices) {
                val existing = deviceDao.getDeviceByMac(dev.macAddress.uppercase())
                if (existing != null) {
                    // Preserve local user edits like custom displayName, notes, block state
                    val merged = dev.copy(
                        displayName = existing.displayName.ifEmpty { dev.displayName },
                        isBlocked = existing.isBlocked,
                        isLimited = existing.isLimited,
                        blockMethod = BlockMethod.fromName(existing.blockMethodName),
                        notes = existing.notes
                    )
                    deviceDao.insertOrUpdate(DeviceEntity.fromDomain(merged))
                } else {
                    deviceDao.insertOrUpdate(DeviceEntity.fromDomain(dev))
                }
                count++
            }
        }

        // Also do a local ARP subnet scan
        val subnet = config.ipAddress.substringBeforeLast(".")
        val scanned = networkScanner.scanLocalSubnet(subnet)
        for (dev in scanned) {
            val existing = deviceDao.getDeviceByMac(dev.macAddress.uppercase())
            if (existing == null) {
                deviceDao.insertOrUpdate(DeviceEntity.fromDomain(dev))
                count++
            }
        }

        return Result.success(count)
    }
}
