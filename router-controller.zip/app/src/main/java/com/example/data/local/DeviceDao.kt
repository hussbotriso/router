package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices ORDER BY isOnline DESC, displayName ASC")
    fun getAllDevices(): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM devices WHERE macAddress = :mac LIMIT 1")
    suspend fun getDeviceByMac(mac: String): DeviceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(device: DeviceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAll(devices: List<DeviceEntity>)

    @Query("DELETE FROM devices WHERE macAddress = :mac")
    suspend fun deleteByMac(mac: String)

    @Query("UPDATE devices SET isBlocked = :isBlocked WHERE macAddress = :mac")
    suspend fun updateBlockState(mac: String, isBlocked: Boolean)

    @Query("UPDATE devices SET isLimited = :isLimited, speedLimitDownKbps = :downKbps, speedLimitUpKbps = :upKbps WHERE macAddress = :mac")
    suspend fun updateSpeedLimits(mac: String, isLimited: Boolean, downKbps: Int, upKbps: Int)
}
