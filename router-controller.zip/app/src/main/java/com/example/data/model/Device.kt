package com.example.data.model

data class Device(
    val macAddress: String,
    val displayName: String,
    val ipAddress: String = "",
    val isBlocked: Boolean = false,
    val isLimited: Boolean = false,
    val speedLimitDownKbps: Int = 0,
    val speedLimitUpKbps: Int = 0,
    val blockMethod: BlockMethod = BlockMethod.IP_MAC_FILTER,
    val lastSeen: Long = System.currentTimeMillis(),
    val notes: String = "",
    val vendor: String = "Unknown Device",
    val isOnline: Boolean = true,
    val deviceType: String = "Generic"
) {
    val formattedMac: String
        get() = macAddress.uppercase()

    val formattedSpeedLimit: String
        get() {
            if (!isLimited || (speedLimitDownKbps <= 0 && speedLimitUpKbps <= 0)) {
                return "Full Speed"
            }
            val downMbps = speedLimitDownKbps / 1024.0
            val upMbps = speedLimitUpKbps / 1024.0
            return String.format("%.1f Mbps ↓ / %.1f Mbps ↑", downMbps, upMbps)
        }
}
