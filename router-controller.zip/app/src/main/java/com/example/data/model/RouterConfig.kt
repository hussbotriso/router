package com.example.data.model

data class RouterConfig(
    val ipAddress: String = "192.168.1.1",
    val username: String = "admin",
    val password: String = "admin",
    val routerModel: String = "TP-LINK ADSL2+ Modem/Router",
    val httpPort: Int = 80,
    val lastConnectedTimestamp: Long = 0L,
    val isConnected: Boolean = false
) {
    val baseUrl: String
        get() = "http://$ipAddress:$httpPort"
}
