package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RouterLogDao {
    @Query("SELECT * FROM router_logs ORDER BY timestamp DESC LIMIT 200")
    fun getAllLogs(): Flow<List<RouterLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: RouterLogEntity)

    @Query("DELETE FROM router_logs")
    suspend fun clearLogs()
}
