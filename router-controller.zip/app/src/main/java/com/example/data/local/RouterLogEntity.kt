package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.RouterLog

@Entity(tableName = "router_logs")
data class RouterLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val deviceName: String,
    val macAddress: String,
    val action: String,
    val status: String,
    val details: String,
    val errorMessage: String
) {
    fun toDomain(): RouterLog {
        return RouterLog(
            id = id,
            timestamp = timestamp,
            deviceName = deviceName,
            macAddress = macAddress,
            action = action,
            status = status,
            details = details,
            errorMessage = errorMessage
        )
    }

    companion object {
        fun fromDomain(log: RouterLog): RouterLogEntity {
            return RouterLogEntity(
                id = log.id,
                timestamp = log.timestamp,
                deviceName = log.deviceName,
                macAddress = log.macAddress,
                action = log.action,
                status = log.status,
                details = log.details,
                errorMessage = log.errorMessage
            )
        }
    }
}
