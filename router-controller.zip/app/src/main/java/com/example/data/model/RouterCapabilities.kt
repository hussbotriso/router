package com.example.data.model

data class RouterCapabilities(
    val supportsIpMacFilter: Boolean = true,
    val supportsAcl: Boolean = true,
    val supportsQos: Boolean = false,
    val supportsArpImport: Boolean = true,
    val detectedModelName: String = "TP-LINK TD-W8961N / ADSL2+ Legacy",
    val activeControlMode: String = "Mode A (Full Router Automation)"
)
