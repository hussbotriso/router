package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.RouterConfig

class SecurePreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("router_credentials_secure", Context.MODE_PRIVATE)

    fun getRouterConfig(): RouterConfig {
        return RouterConfig(
            ipAddress = prefs.getString(KEY_IP, "192.168.1.1") ?: "192.168.1.1",
            username = prefs.getString(KEY_USERNAME, "admin") ?: "admin",
            password = prefs.getString(KEY_PASSWORD, "admin") ?: "admin",
            routerModel = prefs.getString(KEY_MODEL, "TP-LINK ADSL2+ Modem/Router") ?: "TP-LINK ADSL2+ Modem/Router",
            httpPort = prefs.getInt(KEY_PORT, 80),
            lastConnectedTimestamp = prefs.getLong(KEY_LAST_CONNECTED, 0L),
            isConnected = prefs.getBoolean(KEY_IS_CONNECTED, false)
        )
    }

    fun saveRouterConfig(config: RouterConfig) {
        prefs.edit()
            .putString(KEY_IP, config.ipAddress)
            .putString(KEY_USERNAME, config.username)
            .putString(KEY_PASSWORD, config.password)
            .putString(KEY_MODEL, config.routerModel)
            .putInt(KEY_PORT, config.httpPort)
            .putLong(KEY_LAST_CONNECTED, config.lastConnectedTimestamp)
            .putBoolean(KEY_IS_CONNECTED, config.isConnected)
            .apply()
    }

    companion object {
        private const val KEY_IP = "router_ip"
        private const val KEY_USERNAME = "router_user"
        private const val KEY_PASSWORD = "router_pass"
        private const val KEY_MODEL = "router_model"
        private const val KEY_PORT = "router_port"
        private const val KEY_LAST_CONNECTED = "last_connected"
        private const val KEY_IS_CONNECTED = "is_connected"
    }
}
