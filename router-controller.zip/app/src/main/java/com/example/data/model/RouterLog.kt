package com.example.data.model

data class RouterLog(
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val deviceName: String,
    val macAddress: String,
    val action: String,
    val status: String,
    val details: String,
    val errorMessage: String = ""
)
