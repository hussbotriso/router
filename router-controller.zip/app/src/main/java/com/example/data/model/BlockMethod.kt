package com.example.data.model

enum class BlockMethod(
    val displayName: String,
    val description: String,
    val disconnectsWifi: Boolean
) {
    IP_MAC_FILTER(
        displayName = "IP/MAC Blacklist Filter",
        description = "Blocks WAN internet access on router while device remains connected to Wi-Fi.",
        disconnectsWifi = false
    ),
    ACL_BLACKLIST(
        displayName = "ACL Access Control",
        description = "Blocks gateway forwarding and router access. Keeps local Wi-Fi association.",
        disconnectsWifi = false
    ),
    IP_FIREWALL(
        displayName = "IP Firewall Rule",
        description = "Drops all outgoing IP packets from this IP address on the WAN interface.",
        disconnectsWifi = false
    ),
    DNS_BLOCK(
        displayName = "DNS Resolution Block",
        description = "Prevents domain name lookup on router DNS server.",
        disconnectsWifi = false
    ),
    MAC_FILTER_DISCONNECT(
        displayName = "Wireless MAC Filtering",
        description = "Rejects wireless association at access point level. DISCONNECTS Wi-Fi TOO.",
        disconnectsWifi = true
    );

    companion object {
        fun fromName(name: String): BlockMethod {
            return entries.find { it.name == name } ?: IP_MAC_FILTER
        }
    }
}
