package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.BlockMethod
import com.example.data.model.Device

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val macAddress: String,
    val displayName: String,
    val ipAddress: String,
    val isBlocked: Boolean,
    val isLimited: Boolean,
    val speedLimitDownKbps: Int,
    val speedLimitUpKbps: Int,
    val blockMethodName: String,
    val lastSeen: Long,
    val notes: String,
    val vendor: String,
    val isOnline: Boolean,
    val deviceType: String
) {
    fun toDomain(): Device {
        return Device(
            macAddress = macAddress,
            displayName = displayName,
            ipAddress = ipAddress,
            isBlocked = isBlocked,
            isLimited = isLimited,
            speedLimitDownKbps = speedLimitDownKbps,
            speedLimitUpKbps = speedLimitUpKbps,
            blockMethod = BlockMethod.fromName(blockMethodName),
            lastSeen = lastSeen,
            notes = notes,
            vendor = vendor,
            isOnline = isOnline,
            deviceType = deviceType
        )
    }

    companion object {
        fun fromDomain(device: Device): DeviceEntity {
            return DeviceEntity(
                macAddress = device.macAddress.uppercase(),
                displayName = device.displayName,
                ipAddress = device.ipAddress,
                isBlocked = device.isBlocked,
                isLimited = device.isLimited,
                speedLimitDownKbps = device.speedLimitDownKbps,
                speedLimitUpKbps = device.speedLimitUpKbps,
                blockMethodName = device.blockMethod.name,
                lastSeen = device.lastSeen,
                notes = device.notes,
                vendor = device.vendor,
                isOnline = device.isOnline,
                deviceType = device.deviceType
            )
        }
    }
}
