package com.example.router

import com.example.data.model.BlockMethod
import com.example.data.model.Device
import com.example.data.model.RouterConfig

data class RouterManualRule(
    val title: String,
    val menuPath: String,
    val ruleType: String,
    val macAddress: String,
    val ipAddress: String,
    val direction: String,
    val protocol: String,
    val actionText: String,
    val copyableSummary: String,
    val instructions: List<String>
)

object RuleGenerator {

    fun generateRule(config: RouterConfig, device: Device): RouterManualRule {
        val ip = device.ipAddress.ifEmpty { "192.168.1.XXX" }
        val mac = device.macAddress.uppercase()

        return when (device.blockMethod) {
            BlockMethod.IP_MAC_FILTER -> RouterManualRule(
                title = "TP-LINK IP/MAC Filter Rule",
                menuPath = "Access Management → Filter → IP/MAC Filter",
                ruleType = "IP/MAC Filter (Blacklist)",
                macAddress = mac,
                ipAddress = ip,
                direction = "OUT (WAN)",
                protocol = "ALL",
                actionText = "DROP / Deny",
                copyableSummary = "MAC: $mac | IP: $ip | Action: DROP | Menu: Access Management > Filter",
                instructions = listOf(
                    "Open browser at http://${config.ipAddress}",
                    "Log in with Username: ${config.username}",
                    "Navigate to: Access Management → Filter",
                    "Select Filter Type: IP/MAC Filter",
                    "Active: Yes | Rule Type: Blacklist / Deny",
                    "Source MAC: $mac",
                    "Source IP: $ip",
                    "Direction: OUT | Protocol: ALL",
                    "Click Save to apply rule"
                )
            )

            BlockMethod.ACL_BLACKLIST -> RouterManualRule(
                title = "TP-LINK ACL Blacklist Rule",
                menuPath = "Access Management → ACL",
                ruleType = "ACL (Access Control List)",
                macAddress = mac,
                ipAddress = ip,
                direction = "Both (LAN & WAN)",
                protocol = "ALL",
                actionText = "Deny / Disable",
                copyableSummary = "ACL Rule | IP: $ip | MAC: $mac | State: Deactivated",
                instructions = listOf(
                    "Open browser at http://${config.ipAddress}",
                    "Navigate to: Access Management → ACL",
                    "Add new ACL Index rule",
                    "Set IP Address: $ip",
                    "Set MAC Address: $mac",
                    "Set Application: ALL | Interface: LAN",
                    "Action: Deny / Deactive",
                    "Save and reboot router if prompted"
                )
            )

            BlockMethod.IP_FIREWALL -> RouterManualRule(
                title = "TP-LINK Outbound Firewall Rule",
                menuPath = "Advanced Setup → Firewall → Outbound Filter",
                ruleType = "Outbound IP Filter",
                macAddress = mac,
                ipAddress = ip,
                direction = "Outbound",
                protocol = "TCP/UDP",
                actionText = "Block / Reject",
                copyableSummary = "Firewall Rule | Source IP: $ip | Protocol: TCP/UDP | Action: Block",
                instructions = listOf(
                    "Open browser at http://${config.ipAddress}",
                    "Navigate to: Advanced Setup → Firewall",
                    "Enable Firewall if not already active",
                    "Add Outbound Rule: Source IP = $ip",
                    "Port Range: 1-65535",
                    "Action: Block / Deny",
                    "Click Save"
                )
            )

            BlockMethod.DNS_BLOCK -> RouterManualRule(
                title = "DNS Domain Filter Rule",
                menuPath = "Access Management → Domain Filter",
                ruleType = "Domain / URL Filter",
                macAddress = mac,
                ipAddress = ip,
                direction = "DNS Lookup",
                protocol = "UDP/53",
                actionText = "Block All Web Domains",
                copyableSummary = "Domain Filter | Target IP: $ip | Block Keyword: *",
                instructions = listOf(
                    "Open http://${config.ipAddress} in browser",
                    "Navigate to: Access Management → Domain Filter",
                    "Enable Domain Filtering",
                    "Specify Device IP: $ip",
                    "Set Keyword: * (Wildcard)",
                    "Click Save"
                )
            )

            BlockMethod.MAC_FILTER_DISCONNECT -> RouterManualRule(
                title = "Wireless MAC Address Filter (Disconnects Wi-Fi)",
                menuPath = "Interface Setup → Wireless → MAC Filtering",
                ruleType = "Wireless AP Association Filter",
                macAddress = mac,
                ipAddress = ip,
                direction = "Wireless Inbound",
                protocol = "802.11 Wi-Fi",
                actionText = "Deny Association (Disconnects Wi-Fi too)",
                copyableSummary = "Wi-Fi MAC Filter | MAC: $mac | Action: Deny / Deny Association",
                instructions = listOf(
                    "Open http://${config.ipAddress} in browser",
                    "Navigate to: Interface Setup → Wireless",
                    "Scroll to Wireless MAC Address Filter",
                    "Action: Deny the stations specified",
                    "Add MAC Address: $mac",
                    "Click Save (Note: This will disconnect the device from Wi-Fi entirely)"
                )
            )
        }
    }
}
