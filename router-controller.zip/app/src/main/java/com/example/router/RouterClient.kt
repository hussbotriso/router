package com.example.router

import com.example.data.model.Device
import com.example.data.model.RouterCapabilities
import com.example.data.model.RouterConfig

interface RouterClient {
    suspend fun testConnection(config: RouterConfig): Result<RouterCapabilities>
    suspend fun login(config: RouterConfig): Result<String>
    suspend fun fetchConnectedDevices(config: RouterConfig): Result<List<Device>>
    suspend fun blockDevice(config: RouterConfig, device: Device): Result<Boolean>
    suspend fun unblockDevice(config: RouterConfig, device: Device): Result<Boolean>
    suspend fun setDeviceSpeedLimit(config: RouterConfig, device: Device, downKbps: Int, upKbps: Int): Result<Boolean>
}
