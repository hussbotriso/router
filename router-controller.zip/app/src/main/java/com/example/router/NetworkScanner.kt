package com.example.router

import com.example.data.model.Device
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.FileReader
import java.net.InetAddress
import java.util.regex.Pattern

class NetworkScanner {

    suspend fun scanLocalSubnet(subnetPrefix: String = "192.168.1"): List<Device> = withContext(Dispatchers.IO) {
        val discoveredDevices = mutableMapOf<String, Device>()

        // 1. Read system ARP table from /proc/net/arp
        val arpDevices = readArpTable()
        for (dev in arpDevices) {
            discoveredDevices[dev.macAddress.uppercase()] = dev
        }

        // 2. Ping a range of IP addresses on the subnet to trigger ARP resolution
        try {
            for (i in 100..120) {
                val ip = "$subnetPrefix.$i"
                try {
                    val address = InetAddress.getByName(ip)
                    address.isReachable(80)
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}

        // 3. Read ARP table again to pick up newly resolved devices
        val refreshedArp = readArpTable()
        for (dev in refreshedArp) {
            discoveredDevices[dev.macAddress.uppercase()] = dev
        }

        discoveredDevices.values.toList()
    }

    private fun readArpTable(): List<Device> {
        val list = mutableListOf<Device>()
        try {
            val br = BufferedReader(FileReader("/proc/net/arp"))
            var line: String?
            val macPattern = Pattern.compile("([0-9A-FA-f]{2}[:-]){5}([0-9A-FA-f]{2})")

            while (br.readLine().also { line = it } != null) {
                val currentLine = line ?: continue
                if (currentLine.contains("IP address") || currentLine.contains("0x0")) continue

                val parts = currentLine.split("\\s+".toRegex())
                if (parts.size >= 4) {
                    val ip = parts[0]
                    val mac = parts[3].uppercase()

                    if (macPattern.matcher(mac).matches() && mac != "00:00:00:00:00:00") {
                        val vendor = inferVendor(mac)
                        list.add(
                            Device(
                                macAddress = mac,
                                displayName = "$vendor (${mac.takeLast(5)})",
                                ipAddress = ip,
                                vendor = vendor,
                                isOnline = true
                            )
                        )
                    }
                }
            }
            br.close()
        } catch (_: Exception) {
            // /proc/net/arp may be restricted on some Android 10+ devices
        }
        return list
    }

    private fun inferVendor(mac: String): String {
        val clean = mac.replace(":", "").replace("-", "").take(6).uppercase()
        return when {
            clean.startsWith("001A11") || clean.startsWith("3C52A1") -> "Apple Device"
            clean.startsWith("0021E8") || clean.startsWith("503275") -> "Samsung Galaxy"
            clean.startsWith("001310") || clean.startsWith("74D02B") -> "TP-Link Extender/Router"
            clean.startsWith("34E6D7") || clean.startsWith("9405B6") -> "Xiaomi Smart Home"
            clean.startsWith("CCB8A8") -> "LG Smart TV"
            clean.startsWith("70EE50") -> "Netgear Device"
            else -> "LAN Connected Device"
        }
    }
}
