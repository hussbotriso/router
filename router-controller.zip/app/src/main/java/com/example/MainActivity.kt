package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Router
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.ActivityLogsScreen
import com.example.ui.screens.AddDeviceDialog
import com.example.ui.screens.DeviceDetailScreen
import com.example.ui.screens.DeviceListScreen
import com.example.ui.screens.RouterSettingsScreen
import com.example.ui.theme.RouterControllerTheme
import com.example.ui.viewmodel.MainViewModel

enum class NavTab(val label: String, val icon: ImageVector) {
    DEVICES("Devices", Icons.Default.Devices),
    SETTINGS("Router Settings", Icons.Default.Router),
    LOGS("Activity Logs", Icons.Default.History)
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            RouterControllerTheme {
                val state by viewModel.uiState.collectAsStateWithLifecycle()
                var currentTab by remember { mutableStateOf(NavTab.DEVICES) }

                Scaffold(
                    bottomBar = {
                        if (state.selectedDeviceForEdit == null) {
                            NavigationBar(
                                containerColor = Color.White,
                                tonalElevation = 8.dp,
                                modifier = Modifier.testTag("bottom_nav_bar")
                            ) {
                                NavTab.entries.forEach { tab ->
                                    NavigationBarItem(
                                        selected = currentTab == tab,
                                        onClick = { currentTab = tab },
                                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                                        label = {
                                            Text(
                                                text = tab.label,
                                                fontWeight = if (currentTab == tab) FontWeight.Bold else FontWeight.Medium
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            indicatorColor = Color(0xFFDBEAFE),
                                            selectedIconColor = Color(0xFF2563EB),
                                            selectedTextColor = Color(0xFF2563EB),
                                            unselectedIconColor = Color(0xFF64748B),
                                            unselectedTextColor = Color(0xFF64748B)
                                        ),
                                        modifier = Modifier.testTag("nav_item_${tab.name.lowercase()}")
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        val selectedDevice = state.selectedDeviceForEdit
                        if (selectedDevice != null) {
                            DeviceDetailScreen(
                                device = selectedDevice,
                                routerConfig = state.routerConfig,
                                onSave = { updatedDevice ->
                                    viewModel.saveDevice(updatedDevice)
                                },
                                onDelete = { mac ->
                                    viewModel.deleteDevice(mac)
                                },
                                onBack = {
                                    viewModel.setSelectedDeviceForEdit(null)
                                }
                            )
                        } else {
                            when (currentTab) {
                                NavTab.DEVICES -> DeviceListScreen(
                                    state = state,
                                    onToggleBlock = { device, block ->
                                        viewModel.toggleDeviceBlock(device, block)
                                    },
                                    onSelectDevice = { device ->
                                        viewModel.setSelectedDeviceForEdit(device)
                                    },
                                    onRefresh = {
                                        viewModel.refreshDevices()
                                    },
                                    onAddDeviceClick = {
                                        viewModel.setAddDeviceDialogOpen(true)
                                    },
                                    onFilterSelect = { category ->
                                        viewModel.setFilterCategory(category)
                                    }
                                )

                                NavTab.SETTINGS -> RouterSettingsScreen(
                                    config = state.routerConfig,
                                    capabilities = state.routerCapabilities,
                                    isTestConnecting = state.isTestConnecting,
                                    onSaveConfig = { newConfig ->
                                        viewModel.saveRouterConfig(newConfig)
                                    },
                                    onTestConnection = {
                                        viewModel.testRouterConnection()
                                    }
                                )

                                NavTab.LOGS -> ActivityLogsScreen(
                                    logs = state.logs,
                                    onClearLogs = {
                                        viewModel.clearLogs()
                                    }
                                )
                            }
                        }

                        if (state.isAddDeviceDialogOpen) {
                            AddDeviceDialog(
                                onDismiss = { viewModel.setAddDeviceDialogOpen(false) },
                                onAddDevice = { newDevice ->
                                    viewModel.saveDevice(newDevice)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
