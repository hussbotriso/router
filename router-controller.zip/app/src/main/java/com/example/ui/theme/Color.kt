package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Navy900 = Color(0xFF0F172A)
val Navy800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)

val PrimaryBlue = Color(0xFF2563EB)
val PrimaryBlueLight = Color(0xFF60A5FA)

val StateGreen = Color(0xFF10B981)
val StateGreenLight = Color(0xFFD1FAE5)

val StateRed = Color(0xFFEF4444)
val StateRedLight = Color(0xFFFEE2E2)

val StateAmber = Color(0xFFF59E0B)
val StateAmberLight = Color(0xFFFEF3C7)

val SurfaceDark = Color(0xFF0F172A)
val CardDark = Color(0xFF1E293B)

