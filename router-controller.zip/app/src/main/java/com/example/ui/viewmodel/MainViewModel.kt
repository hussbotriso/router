package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.SecurePreferencesManager
import com.example.data.model.BlockMethod
import com.example.data.model.Device
import com.example.data.model.RouterCapabilities
import com.example.data.model.RouterConfig
import com.example.data.model.RouterLog
import com.example.data.repository.DeviceRepository
import com.example.data.repository.RouterRepository
import com.example.router.NetworkScanner
import com.example.router.TpLinkLegacyRouterClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class FilterCategory { ALL, ONLINE, BLOCKED, LIMITED }

data class MainUiState(
    val devices: List<Device> = emptyList(),
    val logs: List<RouterLog> = emptyList(),
    val routerConfig: RouterConfig = RouterConfig(),
    val routerCapabilities: RouterCapabilities = RouterCapabilities(),
    val isLoading: Boolean = false,
    val isScanning: Boolean = false,
    val actionInProgressMac: String? = null,
    val userMessage: String? = null,
    val filterCategory: FilterCategory = FilterCategory.ALL,
    val selectedDeviceForEdit: Device? = null,
    val isAddDeviceDialogOpen: Boolean = false,
    val isTestConnecting: Boolean = false
) {
    val filteredDevices: List<Device>
        get() = when (filterCategory) {
            FilterCategory.ALL -> devices
            FilterCategory.ONLINE -> devices.filter { it.isOnline }
            FilterCategory.BLOCKED -> devices.filter { it.isBlocked }
            FilterCategory.LIMITED -> devices.filter { it.isLimited }
        }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val securePrefs = SecurePreferencesManager(application)
    private val routerClient = TpLinkLegacyRouterClient()
    private val networkScanner = NetworkScanner()

    val routerRepository = RouterRepository(securePrefs, database.routerLogDao(), routerClient)
    val deviceRepository = DeviceRepository(database.deviceDao(), routerClient, networkScanner, routerRepository)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        // Load router config
        val config = routerRepository.getRouterConfig()
        _uiState.update { it.copy(routerConfig = config) }

        // Observe devices from database
        viewModelScope.launch {
            deviceRepository.allDevices.collect { deviceList ->
                // If database is empty, populate with default sample devices for instant demonstration
                if (deviceList.isEmpty()) {
                    seedDefaultDevices()
                } else {
                    _uiState.update { it.copy(devices = deviceList) }
                }
            }
        }

        // Observe activity logs
        viewModelScope.launch {
            routerRepository.allLogs.collect { logList ->
                _uiState.update { it.copy(logs = logList) }
            }
        }
    }

    private suspend fun seedDefaultDevices() {
        val sampleDevices = listOf(
            Device(
                macAddress = "3C:52:A1:88:99:11",
                displayName = "Living Room Smart TV",
                ipAddress = "192.168.1.102",
                isBlocked = false,
                isLimited = true,
                speedLimitDownKbps = 2048,
                speedLimitUpKbps = 512,
                blockMethod = BlockMethod.IP_MAC_FILTER,
                vendor = "Samsung Electronics",
                deviceType = "Smart TV"
            ),
            Device(
                macAddress = "00:1A:11:44:55:66",
                displayName = "Kid's Tablet",
                ipAddress = "192.168.1.105",
                isBlocked = true,
                isLimited = false,
                blockMethod = BlockMethod.IP_MAC_FILTER,
                vendor = "Apple Inc.",
                deviceType = "Tablet",
                notes = "Blocked after 9 PM"
            ),
            Device(
                macAddress = "74:D0:2B:12:34:56",
                displayName = "Work Laptop",
                ipAddress = "192.168.1.110",
                isBlocked = false,
                isLimited = false,
                blockMethod = BlockMethod.IP_MAC_FILTER,
                vendor = "Lenovo",
                deviceType = "Laptop"
            ),
            Device(
                macAddress = "50:32:75:AA:BB:CC",
                displayName = "Main Smartphone",
                ipAddress = "192.168.1.101",
                isBlocked = false,
                isLimited = false,
                blockMethod = BlockMethod.IP_MAC_FILTER,
                vendor = "Google Pixel",
                deviceType = "Phone"
            )
        )
        for (dev in sampleDevices) {
            deviceRepository.saveDevice(dev)
        }
    }

    fun refreshDevices() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true, isLoading = true) }
            val result = deviceRepository.refreshFromRouter(_uiState.value.routerConfig)
            _uiState.update {
                it.copy(
                    isScanning = false,
                    isLoading = false,
                    userMessage = if (result.isSuccess) "Refreshed devices on subnet!" else "Refresh finished with cached devices."
                )
            }
        }
    }

    fun toggleDeviceBlock(device: Device, block: Boolean) {
        viewModelScope.launch {
            _uiState.update { it.copy(actionInProgressMac = device.macAddress) }
            val result = deviceRepository.toggleBlockState(_uiState.value.routerConfig, device, block)
            _uiState.update {
                it.copy(
                    actionInProgressMac = null,
                    userMessage = if (block) "Blocked internet for ${device.displayName}" else "Restored internet for ${device.displayName}"
                )
            }
        }
    }

    fun updateDeviceSpeedLimits(device: Device, isLimited: Boolean, downKbps: Int, upKbps: Int) {
        viewModelScope.launch {
            _uiState.update { it.copy(actionInProgressMac = device.macAddress) }
            deviceRepository.updateSpeedLimits(_uiState.value.routerConfig, device, isLimited, downKbps, upKbps)
            _uiState.update {
                it.copy(
                    actionInProgressMac = null,
                    userMessage = "Speed limit updated for ${device.displayName}"
                )
            }
        }
    }

    fun saveDevice(device: Device) {
        viewModelScope.launch {
            deviceRepository.saveDevice(device)
            _uiState.update {
                it.copy(
                    selectedDeviceForEdit = null,
                    isAddDeviceDialogOpen = false,
                    userMessage = "Saved profile for ${device.displayName}"
                )
            }
        }
    }

    fun deleteDevice(macAddress: String) {
        viewModelScope.launch {
            deviceRepository.deleteDevice(macAddress)
            _uiState.update {
                it.copy(
                    selectedDeviceForEdit = null,
                    userMessage = "Deleted device profile"
                )
            }
        }
    }

    fun saveRouterConfig(config: RouterConfig) {
        viewModelScope.launch {
            routerRepository.saveRouterConfig(config)
            _uiState.update { it.copy(routerConfig = config, userMessage = "Router settings saved!") }
        }
    }

    fun testRouterConnection() {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestConnecting = true) }
            val config = _uiState.value.routerConfig
            val result = routerRepository.testConnection(config)
            _uiState.update {
                it.copy(
                    isTestConnecting = false,
                    routerCapabilities = result.getOrDefault(RouterCapabilities()),
                    userMessage = if (result.isSuccess) "Successfully connected to Router at ${config.ipAddress}!" else "Cannot connect to router: ${result.exceptionOrNull()?.message}"
                )
            }
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            routerRepository.clearLogs()
            _uiState.update { it.copy(userMessage = "Cleared activity logs") }
        }
    }

    fun setFilterCategory(category: FilterCategory) {
        _uiState.update { it.copy(filterCategory = category) }
    }

    fun setSelectedDeviceForEdit(device: Device?) {
        _uiState.update { it.copy(selectedDeviceForEdit = device) }
    }

    fun setAddDeviceDialogOpen(open: Boolean) {
        _uiState.update { it.copy(isAddDeviceDialogOpen = open) }
    }

    fun clearUserMessage() {
        _uiState.update { it.copy(userMessage = null) }
    }
}
